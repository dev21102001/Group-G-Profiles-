package com.example.ourprofile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class PayalActivity extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payal);
    }

    // set backbutton
    public void backbtn (View view) {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    public void aboutMe (View view) {
        startActivity(new Intent(getApplicationContext(), KomalAboutMeActivity.class));
    }

    public void myGoals (View view) {
        startActivity(new Intent(getApplicationContext(), KomalGoalsActivity.class));

    }
}

package com.example.ourprofile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class DivanshuGoalsActivity extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_divanshu_goals);
    }

    public void backbtn (View view) {
        startActivity(new Intent(getApplicationContext(), DivyanshuActivity.class));
    }
}
